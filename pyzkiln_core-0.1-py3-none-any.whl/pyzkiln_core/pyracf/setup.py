

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import subprocess
import sys
import os

from setuptools import setup, find_packages
from setuptools.command.install import install

class MakeError(Exception):
    pass

class Install(install):
    """Customized setuptools install command - builds protos on install."""
    def run(self):
        install.run(self)
        default_path = os.getcwd()
        try:
            os.chdir(os.path.dirname(__file__))
            subprocess.check_call(["make", "all"])
        except Exception as e:
            raise MakeError(f"An Error occured while running make for {os.path.dirname(__file__)}:\n {e}")
        finally:
            os.chdir(default_path)
        
    
setup(
    name = "pyzkiln_core",
    version = "0.1",
    author = "Luisa Martinez, Frank De Gilio, Lei Wang",
    author_email = "martinel@us.ibm.com, degilio@us.ibm.com, wlwangwl@cn.ibm.com",
    description = "",
    license = "Apache", 
    url = "https://github.com/ambitus/pyzkiln/tree/main/pyzkiln_core/pyracf", 
    packages = find_packages(),
    long_description = open("README.md", "r").read(),
    long_description_content_type = 'text/markdown',
    include_package_data = True,
    classifiers = [
        "Programming Language :: Python :: 3",
        "License ::  Apache License",
        "Operating System :: z/OS ",
    ],
    install_requires = [], 
    python_requires = '>=3.6',
    cmdclass = {
        'install': Install,
    }
)

    